X Games Hospital Model Pack

copy lamp and screen folders into \FPS Creator\Files\effectbank

enjoy :)

For more FPSC stuff visit my site!

http://www.fps-x-games.com/